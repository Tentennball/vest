const sharedData = require("../../runtime_data");

const initUser = (socket) => {
  socket.on("user-init", (data) => {
    console.log(`USER ${data.userId} connected`);
    sharedData.userSockets[data.userId] = socket.id;
    if (sharedData.adminNum == 0) {
      console.log(`No Admin -> USER ${data.userId} to Waiting Queue`);
      sharedData.waitingQueue.push(data.userId);
      return;
    }
    // const adminNumber = Math.random() * MAX_ADMIN;
    const adminNumber = 1;
    sharedData.userToAdmin[data.userId] = 1;
    sharedData.adminList[adminNumber].push(data.userId);
    socket
      .to(sharedData.adminSockets[adminNumber])
      .emit("admin-get-roomid", data.userId);
    sharedData.userNum++;
  });
};

module.exports = { initUser };

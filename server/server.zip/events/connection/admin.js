const sharedData = require("../../runtime_data");

const initAdmin = (socket) => {
  socket.on("admin-init", (data) => {
    console.log(`ADMIN ${data.adminId} connected`);
    sharedData.adminSockets[data.adminId] = socket.id;
    sharedData.adminList[data.adminId] = [];
    sharedData.adminNum++;
    if (sharedData.waitingQueue.length > 0) {
      sharedData.waitingQueue.forEach((clnt) => {
        sharedData.adminList[data.adminId].push(clnt);
        sharedData.userToAdmin[clnt] = data.adminId;
        console.log(`${clnt} to ${data.adminId} from Waiting Queue`);
        socket
          .to(sharedData.adminSockets[data.adminId])
          .emit("admin-get-roomid", data.userId);
      });
      sharedData.waitingQueue = [];
    }
  });
};

module.exports = { initAdmin };

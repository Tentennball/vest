const sharedData = require("../../runtime_data");

const disconnect = (socket) => {
  socket.on("disconnect", (data) => {
    console.log(
      `Client disconnected: ${data.isAdmin ? "Admin" : "User"} : ${socket.id}`
    );
    // const rooms = Object.keys(socket.rooms);
    // rooms.forEach((room) => {
    //   if (room !== socket.id) {
    //     socket.leave(room);
    //     console.log(`Socket ${socket.id} left room ${room}`);
    //   }
    // });
    if (data.isAdmin) {
      sharedData.adminSockets[data.id] = null;
      sharedData.adminNum--;
      if (sharedData.adminNum === 0) return;
      const adminNumber = data.id;
      for (let clnt in sharedData.adminList[adminNumber]) {
        // const replaceAdmin= Math.random() * MAX_ADMIN;
        const replaceAdmin = 1;
        while (sharedData.adminSockets[replaceAdmin] === null) {
          //  replaceAdmin= Math.random() * MAX_ADMIN;
        }
        sharedData.adminList[adminNumber].push(clnt);
      }
    } else {
      sharedData.userNum--;
      sharedData.userToAdmin[data.id] = null;
      sharedData.userSockets[data.id] = null;
    }
  });
};

module.exports = { disconnect };

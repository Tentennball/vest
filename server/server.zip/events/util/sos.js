const sos = () => {
  socket.on("sos", () => {});
};

module.exports = { sos };

const sharedData = require("../../runtime_data");

const processChat = (socket) => {
  socket.on("request-chat", (data) => {
    const rxSocket = data.isAdmin
      ? sharedData.userSockets[data.rx]
      : sharedData.adminSockets[data.rx];

    console.log(JSON.stringify(data));
    socket.to(rxSocket).emit("response-chat", JSON.stringify(data));
    console.log(`${data.tx} sent a chat to ${data.rx},${rxSocket}`);
  });
};
module.exports = { processChat };

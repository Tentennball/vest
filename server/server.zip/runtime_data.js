// admin
let adminList = [];
let adminSockets = [];
let adminNum = 0;

// user
let userToAdmin = [];
let userSockets = [];
let waitingQueue = [];
let userNum = 0;

// exports
module.exports = {
  adminList,
  adminSockets,
  adminNum,
  userToAdmin,
  userSockets,
  userNum,
  waitingQueue,
};

const { initAdmin } = require("./events/connection/admin");
const { processChat } = require("./events/util/chat");
const { initUser } = require("./events/connection/user");
const { disconnect } = require("./events/connection/disconnect");

const Socket = (io) => {
  io.on("connection", (socket) => {
    console.log(`socket connected ${socket.id}`);
    initAdmin(socket);
    initUser(socket);
    processChat(socket);
    disconnect(socket);
  });
  // socket.on("joinRoom", (room) => {
  //   socket.join(room);
  //   console.log(`Socket ${socket.id} joined room ${room}`);
  //   const roomSockets = io.sockets.adapter.rooms.get(room);
  //   console.log(`Sockets in room ${room}:`, io.sockets.adapter.rooms);
  // });
};
module.exports = { Socket };
